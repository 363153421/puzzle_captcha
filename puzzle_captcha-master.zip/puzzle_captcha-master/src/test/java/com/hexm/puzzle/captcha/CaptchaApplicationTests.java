package com.hexm.puzzle.captcha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaptchaApplicationTests {

    @Test
    void contextLoads() {
    }

}
