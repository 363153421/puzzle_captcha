# puzzle_captcha
Java版滑块验证码

## 静态示例图
<p align="center">
  <img src="https://img-blog.csdnimg.cn/20201030093633467.gif#pic_center">
</p>

## 动态示例图
<p align="center">
  <img src="https://img-blog.csdnimg.cn/20201030154625386.gif#pic_center">
</p>
