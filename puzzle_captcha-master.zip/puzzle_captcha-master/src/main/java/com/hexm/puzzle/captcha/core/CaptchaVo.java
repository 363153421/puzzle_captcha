package com.hexm.puzzle.captcha.core;

import lombok.Data;

/**
 * @author hexm
 * @date 2020/10/27 11:00
 */
@Data
public class CaptchaVo {

    private String image1;

    private String image2;
}
